=[   BATTLEFIELD   ]=
=[ By Jonny Arnold ]=

HOWTO:
Type
	python battlefield.py
whilst in this directory.

HAVE FUN!
